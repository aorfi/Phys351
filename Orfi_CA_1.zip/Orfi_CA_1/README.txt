Task 1:
Compile vector_mtx.c and main_task_1.c together then run main_task_1.c

Task 2:
Compile main.c then run as main Orfi_input.txt
