#ifndef INIT_H
#define INIT_H
#include "params.h"

void ReadInParams(char *input_file);
void PrintParams(void);
void InitializeNeq(double *q);
#endif