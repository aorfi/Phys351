Compile all files together: main.c rk4.c evolve.c vector_mtx.c init.c forces.c
Run with: main Orfi_input.txt 

To run with different parameters change Orfi_input
