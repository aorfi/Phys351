#ifndef ANALYSIS_H
#define ANALYSIS_H
//calls WriteResults and GetXP

void WriteResults(double *x, double *p);
void GetXP(double *x, double *p, double *x_now, double *p_now, int it);
// double TotalEnergy(double *x, double *p, int it);

#endif