#ifndef ANALYSIS_H
#define ANALYSIS_H
//calls Kinetic Energy

double KineticEnergy(double *q);

#endif